#include <stdio.h>
#include <stdlib.h>
/* 
 *   This is a c program that does something cool.
 *   Many line comment. 
*/ 

int main(int argc,    // This is the number of things passed into this function.  
         char *argv[] // This is the array of things passed. 
        ){

    printf("========\n");  // This is a single line comment. 
    printf("Hello   \n");
    printf("========\n\n");

    return 0;
}
