// This is just a place where I put the signatures for the 
// Functions I'm building in HelperFunctions.c

int CheckRadius(int TotRows, int TotCols, int Radius, int CurrentPixRow, int CurrentPixCol);
